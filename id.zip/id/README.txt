A Pen created at CodePen.io. You can find this one at http://codepen.io/mauriceconchis/pen/YWBxAg.

 Pure CSS news cards with revealing content on hover. Please feel free to drop a comment with some suggestion for improvement. 