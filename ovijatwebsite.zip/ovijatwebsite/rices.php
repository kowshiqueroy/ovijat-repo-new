<?php include 'head.php'; ?>



<section style="margin-top:30px;">
                <div class="container">
                    <div class="row">
                    
                        <div class="col-lg-10 col-12 text-center mx-auto">
                            <h2 class="mb-5">Rice</h2>
                        </div>

                        <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0">
                            <div class="featured-block d-flex justify-content-center align-items-center">
                                <a href="#featured-block d-flex justify-content-center align-items-center" class="d-block">
                                    <img src="images/p/r.jpg" class="featured-block-image img-fluid" alt="">

                                  <p class="featured-block-text"><strong>Aromatic Kalijeera Rice</strong><br>Details</p>
                                </a>
                            </div>
                        </div>

                       <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0 mb-md-4">
                            <div class="featured-block d-flex justify-content-center align-items-center">
                                <a href="#featured-block d-flex justify-content-center align-items-center" class="d-block">
                                    <img src="images/p/ri.jpg"  class="featured-block-image img-fluid" alt="">
                                    <p class="featured-block-text"><strong>Puffed Rice</strong><br>Details</p>
                                </a>
                            </div>
                        </div>

                       <!-- <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0 mb-md-4">
                            <div class="featured-block d-flex justify-content-center align-items-center">
                                <a href="#featured-block d-flex justify-content-center align-items-center" class="d-block">
                                    <img src="images/p/p1.jpg"  class="featured-block-image img-fluid" alt="">
                                    <p class="featured-block-text"><strong>Jhal Muri</strong><br>Details</p>
                                </a>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0">
                            <div class="featured-block d-flex justify-content-center align-items-center">
                                <a href="#featured-block d-flex justify-content-center align-items-center" class="d-block">
                                    <img src="images/p/p1.jpg"  class="featured-block-image img-fluid" alt="">
                                    <p class="featured-block-text"><strong>Jhal Muri</strong><br>Details</p>
                                </a>
                            </div>
                        </div>

                    </div>
                </div>
            </section>


            <section >
                <div class="container">
                    <div class="row">

                       

                        <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0">
                            <div class="featured-block d-flex justify-content-center align-items-center">
                                <a href="#featured-block d-flex justify-content-center align-items-center" class="d-block">
                                    <img src="images/p/p1.jpg" class="featured-block-image img-fluid" alt="">

                                    <p class="featured-block-text"><strong>Jhal Muri</strong><br>Details</p>
                                </a>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0 mb-md-4">
                            <div class="featured-block d-flex justify-content-center align-items-center">
                                <a href="#featured-block d-flex justify-content-center align-items-center" class="d-block">
                                    <img src="images/p/p1.jpg"  class="featured-block-image img-fluid" alt="">
                                    <p class="featured-block-text"><strong>Jhal Muri</strong><br>Details</p>
                                </a>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0 mb-md-4">
                            <div class="featured-block d-flex justify-content-center align-items-center">
                                <a href="#featured-block d-flex justify-content-center align-items-center" class="d-block">
                                    <img src="images/p/p1.jpg"  class="featured-block-image img-fluid" alt="">
                                    <p class="featured-block-text"><strong>Jhal Muri</strong><br>Details</p>
                                </a>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0">
                            <div class="featured-block d-flex justify-content-center align-items-center">
                                <a href="#featured-block d-flex justify-content-center align-items-center" class="d-block">
                                    <img src="images/p/p1.jpg"  class="featured-block-image img-fluid" alt="">
                                    <p class="featured-block-text"><strong>Jhal Muri</strong><br>Details</p>
                                </a>
                            </div>
                        </div>-->

                    </div>
                </div>
            </section>

           


           



<?php include 'foot.php'; ?>