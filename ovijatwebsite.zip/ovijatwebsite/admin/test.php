<!DOCTYPE html>
<html>
<body>

<?php

echo $_SERVER['SERVER_NAME'];
echo "<br>";
echo $_SERVER['HTTP_HOST'];

?>

</body>
</html>