<?php include 'head.php'; ?>



<section class="cta-section section-padding section-bg">
                <div class="container">
                    <div class="row justify-content-center align-items-center">

                        <div class="col-lg-5 col-12 ms-auto">
                            <h2 class="mb-0">Ovijat will be a premium brand in food industry in the world and a one stop supply house for any kind of foods, apparels and household items for the importers, distributor and wholesalers. We will ensure healthy and hearty lives of people with our products and service.</h2>
                        </div>

                        <div class="col-lg-5 col-12">
                       

                            <a href="" class="custom-btn btn smoothscroll">Ovijat Group' Vission</a>
                        </div>

                    </div>
                </div>
            </section>




<?php include 'foot.php'; ?>