<?php
header('Content-Type:text/html; charset=utf-8');
error_reporting(0); 


