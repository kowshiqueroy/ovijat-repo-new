<?php include 'head.php'; ?>




<section class="section-padding section-bg" id="section_2">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-6 col-12 mb-5 mb-lg-0">
                            <img src="images/chairman.jpg" class="custom-text-box-image img-fluid" alt="">
                        </div>

                        <div class="col-lg-6 col-12">
                            <div class="custom-text-box">
                                <h2 class="mb-2">MD MOSTAFIZUR RAHMAN</h2>
                                
                                <h5 class="mb-3">CHAIRMAN, OVIJAT FOOD & BEVERAGE INDUSTRIES LTD.</h5>

                                <p class="mb-0">THE NEW ERA HAS BEGUN FOR OVIJAT FOOD.

We are moving forward with dynamism, guided by our vision for the continuous development of one of the most competitive industrial companies, with a strong presence in several key sectors of global economy.

We take great pride and pleasure that the company Ovijat Food & Beverage industries Ltd. has attained impressive and sustained growth over the past decade. I would like to express my personal gratitude to all our partners, business allies and customers who have shown full confidence in us. It is the Confidence bestowed on us by all the partners that empowers and inspired us at every steps in our operations.

We are an organization that operates at highest standard of quality, purity, managerial and operational skills. We are a company founded entrepreneurs aimed at achieving success through delivery of high quality products to most discerning global customers.

Ovijat Group is an emerging group in home and abroad markets and in line with the global growth strategy. We have always implemented new initiatives in sales and marketing, manufacturing supply chain, research and development. We constantly aim at enhancing our market share through “Value Differentiation with Customer Satisfaction”.

Once again, I would like to express my greatest appreciation for the continued support from the farmers, trade business partner, suppliers, business associates and the potential customers. I am sure that together we can take Ovijat Food & Beverage Industries Ltd. to create highest value pursue with the productive team.</p>
                            </div>
                     
                              
                            
                        </div>

                    </div>
                </div>
            </section>




            <?php include 'foot.php'; ?>