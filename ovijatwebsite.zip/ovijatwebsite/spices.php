<?php include 'head.php'; ?>



<section style="margin-top:30px;">
                <div class="container">
                    <div class="row">
                    
                        <div class="col-lg-10 col-12 text-center mx-auto">
                            <h2 class="mb-5">Spices</h2>
                        </div>

                        <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0">
                            <div class="featured-block d-flex justify-content-center align-items-center">
                                <a href="#featured-block d-flex justify-content-center align-items-center" class="d-block">
                                    <img src="images/p/do.jpg" class="featured-block-image img-fluid" alt="">

                                  <p class="featured-block-text"><strong>Coriander Powder</strong><br></p>
                                </a>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0 mb-md-4">
                            <div class="featured-block d-flex justify-content-center align-items-center">
                                <a href="#featured-block d-flex justify-content-center align-items-center" class="d-block">
                                    <img src="images/p/mi.jpg"  class="featured-block-image img-fluid" alt="">
                                    <p class="featured-block-text"><strong>Whole Dry Chilli</strong><br></p>
                                </a>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0 mb-md-4">
                            <div class="featured-block d-flex justify-content-center align-items-center">
                                <a href="#featured-block d-flex justify-content-center align-items-center" class="d-block">
                                    <img src="images/p/h.jpg"  class="featured-block-image img-fluid" alt="">
                                    <p class="featured-block-text"><strong>Termeric Powder</strong><br></p>
                                </a>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0">
                            <div class="featured-block d-flex justify-content-center align-items-center">
                                <a href="#featured-block d-flex justify-content-center align-items-center" class="d-block">
                                    <img src="images/p/m.jpg"  class="featured-block-image img-fluid" alt="">
                                    <p class="featured-block-text"><strong>Chilli Powder</strong><br></p>
                                </a>
                            </div>
                        </div>

                    </div>
                </div>
            </section>


            <section >
                <div class="container">
                    <div class="row">

                       

                        <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0">
                            <div class="featured-block d-flex justify-content-center align-items-center">
                                <a href="#featured-block d-flex justify-content-center align-items-center" class="d-block">
                                    <img src="images/p/bay_leaf.jpg" class="featured-block-image img-fluid" alt="">

                                    <p class="featured-block-text"><strong>Bay Leafs</strong><br></p>
                                </a>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0 mb-md-4">
                            <div class="featured-block d-flex justify-content-center align-items-center">
                                <a href="#featured-block d-flex justify-content-center align-items-center" class="d-block">
                                    <img src="images/p/ji.jpg"  class="featured-block-image img-fluid" alt="">
                                    <p class="featured-block-text"><strong>Cumin Powder</strong><br></p>
                                </a>
                            </div>
                        </div>

                        <!--<div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0 mb-md-4">
                            <div class="featured-block d-flex justify-content-center align-items-center">
                                <a href="#featured-block d-flex justify-content-center align-items-center" class="d-block">
                                    <img src="images/p/do.jpg"  class="featured-block-image img-fluid" alt="">
                                    <p class="featured-block-text"><strong>Coriander Powder</strong><br>Details</p>
                                </a>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0">
                            <div class="featured-block d-flex justify-content-center align-items-center">
                                <a href="#featured-block d-flex justify-content-center align-items-center" class="d-block">
                                    <img src="images/p/mi.jpg"  class="featured-block-image img-fluid" alt="">
                                    <p class="featured-block-text"><strong>Whole Dry Chilli</strong><br>Details</p>
                                </a>
                            </div>
                        </div>-->

                    </div>
                </div>
            </section>

           


           



<?php include 'foot.php'; ?>