<link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">

<link rel="stylesheet" href="percent-preloader.css" />
</head>

<body>


    <div class="preloader">
      <div class="inner">

        <img style="width:10% " src="images/logo.png"></img>
        <span class="percentage"><span id="percentage">15</span>%</span>
      </div>
      <div class="loader-progress" id="loader-progress"> </div>
    </div>
    <div class="transition-overlay"></div>
    <script src="https://code.jquery.com/jquery-3.6.0.slim.min.js"></script>
    <script src="percent-preloader.js"></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-1VDDWMRSTH"></script>
    <script>
      window.dataLayer = window.dataLayer || [];

      function gtag() {
        dataLayer.push(arguments);
      }
      gtag('js', new Date());
      gtag('config', 'G-1VDDWMRSTH');
    </script>