<?php include 'head.php'; ?>


<section class="cta-section section-padding section-bg">
                <div class="container">
                    <div class="row justify-content-center align-items-center">

                        <div class="col-lg-5 col-12 ms-auto">
                            <h2 class="mb-0">




                            Customer’s preference is always our first priority that why we are also in an international trading of different well-known company’s products & services. Our retail partners can ordered to deliver any product of different companies. We do also care about quality of their products and services when we are exporting their products and services.
                            </h2>
                        </div>

                        <div class="col-lg-1 col-12">
                       

                            <a href="" class="custom-btn btn smoothscroll">USA</a>
                        </div>
                        <div class="col-lg-1 col-12">
                       

                       <a href="" class="custom-btn btn smoothscroll">UAE</a>
                   </div>


                   <div class="col-lg-1 col-12">
                       

                       <a href="" class="custom-btn btn smoothscroll">Others</a>
                   </div>

                    </div>
                </div>
            </section>





<?php include 'foot.php'; ?>